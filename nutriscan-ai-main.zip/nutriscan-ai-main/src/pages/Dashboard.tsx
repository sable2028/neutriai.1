import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Activity, Apple, Droplets, Flame, TrendingUp, Plus } from "lucide-react";
import { Link } from "react-router-dom";

const Dashboard = () => {
  const { toast } = useToast();
  const [foodLog, setFoodLog] = useState([
    { name: "Oatmeal with berries", calories: 320, time: "8:00 AM" },
    { name: "Grilled chicken salad", calories: 450, time: "1:00 PM" },
  ]);
  const [newFood, setNewFood] = useState("");
  const [newCalories, setNewCalories] = useState("");

  const totalCalories = foodLog.reduce((sum, item) => sum + item.calories, 0);
  const dailyGoal = 2000;
  const waterIntake = 6; // glasses
  const waterGoal = 8;

  const handleAddFood = () => {
    if (!newFood || !newCalories) {
      toast({
        title: "Missing Information",
        description: "Please enter both food name and calories.",
        variant: "destructive",
      });
      return;
    }

    const now = new Date();
    const time = now.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });

    setFoodLog([...foodLog, { name: newFood, calories: parseInt(newCalories), time }]);
    setNewFood("");
    setNewCalories("");

    toast({
      title: "Food Logged!",
      description: `${newFood} added to your daily intake.`,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-accent/20 py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-8 animate-fade-in">
          <h1 className="text-3xl md:text-4xl font-bold mb-2 text-foreground">Your Health Dashboard</h1>
          <p className="text-muted-foreground">Track your daily nutrition and progress</p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="p-6 shadow-md animate-fade-in" style={{ animationDelay: "100ms" }}>
            <div className="flex items-center justify-between mb-4">
              <Flame className="w-8 h-8 text-primary" />
              <Badge variant="secondary">Today</Badge>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Calories</p>
              <p className="text-3xl font-bold text-foreground">{totalCalories}</p>
              <p className="text-xs text-muted-foreground mt-1">of {dailyGoal} kcal goal</p>
              <Progress value={(totalCalories / dailyGoal) * 100} className="mt-3 h-2" />
            </div>
          </Card>

          <Card className="p-6 shadow-md animate-fade-in" style={{ animationDelay: "200ms" }}>
            <div className="flex items-center justify-between mb-4">
              <Droplets className="w-8 h-8 text-primary" />
              <Badge variant="secondary">Today</Badge>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Water Intake</p>
              <p className="text-3xl font-bold text-foreground">{waterIntake}</p>
              <p className="text-xs text-muted-foreground mt-1">of {waterGoal} glasses</p>
              <Progress value={(waterIntake / waterGoal) * 100} className="mt-3 h-2" />
            </div>
          </Card>

          <Card className="p-6 shadow-md animate-fade-in" style={{ animationDelay: "300ms" }}>
            <div className="flex items-center justify-between mb-4">
              <Activity className="w-8 h-8 text-secondary" />
              <Badge variant="secondary">This Week</Badge>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Health Score</p>
              <p className="text-3xl font-bold text-foreground">78</p>
              <p className="text-xs text-secondary mt-1 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                +5% from last week
              </p>
            </div>
          </Card>

          <Card className="p-6 shadow-md animate-fade-in" style={{ animationDelay: "400ms" }}>
            <div className="flex items-center justify-between mb-4">
              <Apple className="w-8 h-8 text-secondary" />
              <Badge variant="secondary">This Week</Badge>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Nutrient Balance</p>
              <p className="text-3xl font-bold text-foreground">Good</p>
              <p className="text-xs text-muted-foreground mt-1">2 deficiencies improving</p>
            </div>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Food Log */}
          <Card className="lg:col-span-2 p-6 shadow-lg animate-fade-in" style={{ animationDelay: "500ms" }}>
            <h2 className="text-2xl font-bold mb-4 text-foreground">Today's Food Log</h2>
            
            <div className="space-y-3 mb-6">
              {foodLog.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-accent/30 rounded-lg border border-border">
                  <div>
                    <p className="font-medium text-foreground">{item.name}</p>
                    <p className="text-sm text-muted-foreground">{item.time}</p>
                  </div>
                  <Badge className="bg-primary/10 text-primary border-primary/20">
                    {item.calories} kcal
                  </Badge>
                </div>
              ))}
            </div>

            <div className="space-y-4 p-4 bg-muted/50 rounded-lg border-2 border-dashed border-border">
              <h3 className="font-semibold text-foreground flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Add New Food
              </h3>
              <div className="grid gap-3">
                <div>
                  <Label htmlFor="food-name">Food Name</Label>
                  <Input
                    id="food-name"
                    placeholder="e.g., Banana, Rice bowl"
                    value={newFood}
                    onChange={(e) => setNewFood(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="calories">Calories</Label>
                  <Input
                    id="calories"
                    type="number"
                    placeholder="e.g., 150"
                    value={newCalories}
                    onChange={(e) => setNewCalories(e.target.value)}
                  />
                </div>
                <Button onClick={handleAddFood} className="bg-gradient-primary hover:opacity-90 transition-opacity">
                  Add Food
                </Button>
              </div>
            </div>
          </Card>

          {/* Quick Actions */}
          <Card className="p-6 shadow-lg animate-fade-in" style={{ animationDelay: "600ms" }}>
            <h2 className="text-xl font-bold mb-4 text-foreground">Quick Actions</h2>
            <div className="space-y-3">
              <Link to="/results">
                <Button variant="outline" className="w-full justify-start border-2">
                  <Activity className="w-4 h-4 mr-2" />
                  View Deficiency Report
                </Button>
              </Link>
              <Link to="/symptom-checker">
                <Button variant="outline" className="w-full justify-start border-2">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Re-check Symptoms
                </Button>
              </Link>
              <Button variant="outline" className="w-full justify-start border-2" disabled>
                <Apple className="w-4 h-4 mr-2" />
                Weekly Report (Coming Soon)
              </Button>
            </div>

            <div className="mt-6 p-4 bg-gradient-secondary rounded-lg text-secondary-foreground">
              <h3 className="font-semibold mb-2">💡 Today's Tip</h3>
              <p className="text-sm">
                Try to get 10-15 minutes of morning sunlight to boost your Vitamin D levels naturally!
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
