import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { Activity, Brain, TrendingUp, Utensils } from "lucide-react";

const Home = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-accent/20">
      {/* Hero Section */}
      <section className="container mx-auto px-4 pt-20 pb-16 md:pt-32 md:pb-24">
        <div className="max-w-4xl mx-auto text-center animate-fade-in">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-6 text-sm font-medium">
            <Brain className="w-4 h-4" />
            AI-Powered Health Intelligence
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-hero bg-clip-text text-transparent leading-tight">
            Discover Your Nutritional Deficiencies with AI
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            NutriScan AI analyzes your symptoms, lifestyle, and diet to identify nutritional gaps 
            and provides personalized cure plans with food recommendations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/profile-setup">
              <Button size="lg" className="bg-gradient-primary hover:opacity-90 transition-opacity shadow-lg">
                Start Your Health Journey
              </Button>
            </Link>
            <Link to="/symptom-checker">
              <Button size="lg" variant="outline" className="border-2">
                Check Symptoms Now
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className="p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 animate-fade-in border-border/50"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center mb-4 shadow-md">
                <feature.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-foreground">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* How It Works Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground">
            How It Works
          </h2>
          <div className="space-y-8">
            {steps.map((step, index) => (
              <div 
                key={index} 
                className="flex gap-6 items-start animate-fade-in"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-primary flex items-center justify-center text-primary-foreground font-bold text-lg shadow-md">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-2 text-foreground">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16 mb-16">
        <Card className="max-w-4xl mx-auto p-8 md:p-12 bg-gradient-hero text-primary-foreground text-center shadow-lg">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Transform Your Health?
          </h2>
          <p className="text-lg mb-8 text-primary-foreground/90 max-w-2xl mx-auto">
            Join thousands of users who've discovered their nutritional gaps and improved their health with personalized guidance.
          </p>
          <Link to="/profile-setup">
            <Button size="lg" variant="secondary" className="shadow-lg hover:scale-105 transition-transform">
              Get Started Free
            </Button>
          </Link>
        </Card>
      </section>
    </div>
  );
};

const features = [
  {
    icon: Brain,
    title: "AI Deficiency Detection",
    description: "Advanced AI analyzes your symptoms to identify potential nutritional deficiencies with confidence scores.",
  },
  {
    icon: Utensils,
    title: "Personalized Diet Plans",
    description: "Get customized food recommendations, recipes, and meal plans tailored to your deficiencies.",
  },
  {
    icon: Activity,
    title: "Daily Tracking",
    description: "Log your meals and track calories, nutrients, and progress toward your health goals.",
  },
  {
    icon: TrendingUp,
    title: "Weekly Reports",
    description: "Monitor your health improvements with detailed analytics and actionable insights.",
  },
];

const steps = [
  {
    title: "Create Your Profile",
    description: "Tell us about your age, weight, height, activity level, and any symptoms you're experiencing.",
  },
  {
    title: "AI Symptom Analysis",
    description: "Our AI analyzes your symptoms and lifestyle to identify potential nutritional deficiencies.",
  },
  {
    title: "Get Personalized Cures",
    description: "Receive detailed food recommendations, recipes, and supplement guidance for each deficiency.",
  },
  {
    title: "Track & Improve",
    description: "Log your daily meals, monitor your progress, and watch your health improve over time.",
  },
];

export default Home;
