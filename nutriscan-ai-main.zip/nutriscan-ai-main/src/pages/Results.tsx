import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { AlertCircle, ArrowRight, CheckCircle2, Lightbulb } from "lucide-react";

interface DeficiencyResult {
  name: string;
  confidence: number;
  symptoms: number;
}

interface CureInfo {
  foods: string[];
  recipes: string[];
  supplements: string;
  lifestyle: string[];
}

const deficiencyCures: Record<string, CureInfo> = {
  "Vitamin D": {
    foods: ["Eggs", "Salmon", "Mushrooms", "Fortified Milk", "Tuna"],
    recipes: ["Egg omelette with mushrooms", "Grilled salmon with vegetables", "Tuna salad"],
    supplements: "Vitamin D3 (1000-2000 IU daily, consult doctor)",
    lifestyle: ["10-20 minutes of sunlight exposure daily", "Morning walk in sunlight", "Outdoor activities"],
  },
  "Iron": {
    foods: ["Spinach", "Lentils", "Red Meat", "Chickpeas", "Pumpkin Seeds"],
    recipes: ["Spinach dal", "Lentil soup", "Chickpea curry with rice"],
    supplements: "Iron supplements (if prescribed by doctor)",
    lifestyle: ["Consume vitamin C rich foods with iron", "Avoid tea/coffee with meals", "Cook in iron vessels"],
  },
  "Vitamin B12": {
    foods: ["Eggs", "Milk", "Yogurt", "Cheese", "Chicken", "Fish"],
    recipes: ["Boiled eggs with toast", "Greek yogurt with berries", "Chicken curry"],
    supplements: "B12 tablets or injections (if severe)",
    lifestyle: ["Include dairy daily", "Consider fortified cereals", "Regular health checkups"],
  },
  "Magnesium": {
    foods: ["Almonds", "Cashews", "Avocado", "Dark Chocolate", "Banana"],
    recipes: ["Almond butter smoothie", "Avocado toast", "Banana oatmeal"],
    supplements: "Magnesium supplements (300-400mg daily)",
    lifestyle: ["Reduce caffeine intake", "Manage stress", "Adequate sleep"],
  },
  "Zinc": {
    foods: ["Pumpkin Seeds", "Chickpeas", "Cashews", "Eggs", "Chicken"],
    recipes: ["Roasted chickpeas", "Pumpkin seed trail mix", "Egg curry"],
    supplements: "Zinc tablets (15-30mg daily)",
    lifestyle: ["Limit processed foods", "Stay hydrated", "Balanced protein intake"],
  },
  "Omega-3": {
    foods: ["Flaxseeds", "Walnuts", "Chia Seeds", "Fish Oil", "Salmon"],
    recipes: ["Flaxseed smoothie", "Walnut salad", "Chia pudding"],
    supplements: "Fish oil capsules (1000mg EPA/DHA)",
    lifestyle: ["Include fatty fish 2-3 times/week", "Add seeds to meals", "Reduce trans fats"],
  },
  "Calcium": {
    foods: ["Milk", "Yogurt", "Cheese", "Tofu", "Broccoli"],
    recipes: ["Paneer tikka", "Broccoli soup", "Greek yogurt parfait"],
    supplements: "Calcium tablets with Vitamin D",
    lifestyle: ["Daily dairy consumption", "Weight-bearing exercises", "Reduce soda intake"],
  },
  "Vitamin C": {
    foods: ["Oranges", "Lemon", "Guava", "Bell Peppers", "Strawberries"],
    recipes: ["Orange smoothie", "Lemon water", "Bell pepper stir-fry"],
    supplements: "Vitamin C tablets (500-1000mg)",
    lifestyle: ["Fresh fruits daily", "Raw vegetables", "Avoid overcooking"],
  },
};

const Results = () => {
  const navigate = useNavigate();
  const [results, setResults] = useState<DeficiencyResult[]>([]);

  useEffect(() => {
    const storedResults = localStorage.getItem("deficiencyResults");
    if (storedResults) {
      setResults(JSON.parse(storedResults));
    } else {
      navigate("/symptom-checker");
    }
  }, [navigate]);

  const getSeverityColor = (confidence: number) => {
    if (confidence >= 70) return "text-destructive";
    if (confidence >= 50) return "text-orange-500";
    return "text-yellow-600";
  };

  const getSeverityBadge = (confidence: number) => {
    if (confidence >= 70) return "High Priority";
    if (confidence >= 50) return "Moderate";
    return "Low Risk";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-accent/20 py-12 px-4">
      <div className="container mx-auto max-w-5xl">
        {/* Header */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-4 text-sm font-medium">
            <CheckCircle2 className="w-4 h-4" />
            Analysis Complete
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-3 text-foreground">Your Deficiency Report</h1>
          <p className="text-muted-foreground">AI has analyzed your symptoms and identified potential nutritional gaps</p>
        </div>

        {/* Summary Card */}
        <Card className="p-6 md:p-8 mb-6 shadow-lg animate-fade-in bg-gradient-primary text-primary-foreground" style={{ animationDelay: "100ms" }}>
          <div className="flex items-start gap-4">
            <AlertCircle className="w-8 h-8 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-2xl font-bold mb-2">Found {results.length} Potential Deficiencies</h2>
              <p className="text-primary-foreground/90">
                Based on your symptoms, our AI has identified nutritional gaps that may be affecting your health. 
                Below are personalized recommendations to address each deficiency.
              </p>
            </div>
          </div>
        </Card>

        {/* Results List */}
        <div className="space-y-6">
          {results.map((result, index) => {
            const cureInfo = deficiencyCures[result.name] || {
              foods: ["Consult a nutritionist"],
              recipes: ["Custom diet plan recommended"],
              supplements: "Medical consultation advised",
              lifestyle: ["Professional guidance needed"],
            };

            return (
              <Card key={index} className="p-6 md:p-8 shadow-lg animate-fade-in" style={{ animationDelay: `${(index + 2) * 100}ms` }}>
                {/* Deficiency Header */}
                <div className="flex items-start justify-between mb-6">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-2xl font-bold text-foreground">{result.name} Deficiency</h3>
                      <Badge variant={result.confidence >= 70 ? "destructive" : "secondary"}>
                        {getSeverityBadge(result.confidence)}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">Confidence Score:</span>
                        <span className={`text-lg font-semibold ${getSeverityColor(result.confidence)}`}>
                          {result.confidence}%
                        </span>
                      </div>
                      <Progress value={result.confidence} className="h-2" />
                    </div>
                  </div>
                </div>

                <Separator className="my-6" />

                {/* Foods Section */}
                <div className="mb-6">
                  <h4 className="font-semibold text-lg mb-3 flex items-center gap-2 text-foreground">
                    <Lightbulb className="w-5 h-5 text-secondary" />
                    Foods to Include
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {cureInfo.foods.map((food, idx) => (
                      <Badge key={idx} variant="outline" className="px-3 py-1 bg-secondary/10 border-secondary/30">
                        {food}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Recipes Section */}
                <div className="mb-6">
                  <h4 className="font-semibold text-lg mb-3 text-foreground">Quick Recipes</h4>
                  <ul className="space-y-2">
                    {cureInfo.recipes.map((recipe, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-muted-foreground">
                        <CheckCircle2 className="w-4 h-4 text-secondary flex-shrink-0 mt-0.5" />
                        <span>{recipe}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Supplements Section */}
                <div className="mb-6">
                  <h4 className="font-semibold text-lg mb-2 text-foreground">Supplement Suggestion</h4>
                  <p className="text-muted-foreground bg-accent/50 p-3 rounded-lg border border-border">
                    {cureInfo.supplements}
                  </p>
                </div>

                {/* Lifestyle Section */}
                <div>
                  <h4 className="font-semibold text-lg mb-3 text-foreground">Lifestyle Tips</h4>
                  <ul className="space-y-2">
                    {cureInfo.lifestyle.map((tip, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-muted-foreground">
                        <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </Card>
            );
          })}
        </div>

        {/* CTA Section */}
        <Card className="p-6 md:p-8 mt-8 text-center shadow-lg animate-fade-in" style={{ animationDelay: `${(results.length + 3) * 100}ms` }}>
          <h3 className="text-xl font-bold mb-3 text-foreground">Ready to Track Your Progress?</h3>
          <p className="text-muted-foreground mb-6">
            Start logging your daily meals and monitor how these recommendations improve your health.
          </p>
          <Button size="lg" className="bg-gradient-primary hover:opacity-90 transition-opacity shadow-md" onClick={() => navigate("/dashboard")}>
            Go to Dashboard
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </Card>
      </div>
    </div>
  );
};

export default Results;
