import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Brain, ArrowRight } from "lucide-react";

const symptoms = [
  { id: "fatigue", label: "Chronic Fatigue / Low Energy", deficiencies: ["Iron", "Vitamin B12", "Vitamin D"] },
  { id: "hairfall", label: "Hair Fall / Thinning Hair", deficiencies: ["Iron", "Biotin", "Zinc", "Vitamin D"] },
  { id: "weakness", label: "Muscle Weakness", deficiencies: ["Vitamin D", "Magnesium", "Potassium"] },
  { id: "mood", label: "Mood Swings / Depression", deficiencies: ["Vitamin D", "Vitamin B12", "Omega-3", "Magnesium"] },
  { id: "joint", label: "Joint Pain / Bone Pain", deficiencies: ["Vitamin D", "Calcium", "Vitamin K"] },
  { id: "skin", label: "Dry Skin / Skin Issues", deficiencies: ["Vitamin E", "Vitamin A", "Omega-3", "Zinc"] },
  { id: "nails", label: "Brittle Nails", deficiencies: ["Biotin", "Iron", "Zinc"] },
  { id: "memory", label: "Poor Memory / Brain Fog", deficiencies: ["Vitamin B12", "Iron", "Omega-3"] },
  { id: "immunity", label: "Frequent Infections / Low Immunity", deficiencies: ["Vitamin C", "Vitamin D", "Zinc"] },
  { id: "cramps", label: "Muscle Cramps", deficiencies: ["Magnesium", "Calcium", "Potassium"] },
  { id: "vision", label: "Night Vision Problems", deficiencies: ["Vitamin A"] },
  { id: "wounds", label: "Slow Wound Healing", deficiencies: ["Vitamin C", "Zinc", "Protein"] },
];

const SymptomChecker = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);

  const handleSymptomToggle = (symptomId: string) => {
    setSelectedSymptoms(prev =>
      prev.includes(symptomId)
        ? prev.filter(id => id !== symptomId)
        : [...prev, symptomId]
    );
  };

  const handleAnalyze = () => {
    if (selectedSymptoms.length === 0) {
      toast({
        title: "No Symptoms Selected",
        description: "Please select at least one symptom to analyze.",
        variant: "destructive",
      });
      return;
    }

    // Calculate deficiency probabilities based on selected symptoms
    const deficiencyCount: Record<string, number> = {};
    
    selectedSymptoms.forEach(symptomId => {
      const symptom = symptoms.find(s => s.id === symptomId);
      symptom?.deficiencies.forEach(def => {
        deficiencyCount[def] = (deficiencyCount[def] || 0) + 1;
      });
    });

    // Convert to results with confidence scores
    const results = Object.entries(deficiencyCount)
      .map(([name, count]) => ({
        name,
        confidence: Math.min(Math.round((count / selectedSymptoms.length) * 100), 95),
        symptoms: selectedSymptoms.length,
      }))
      .sort((a, b) => b.confidence - a.confidence);

    // Store results
    localStorage.setItem("deficiencyResults", JSON.stringify(results));
    localStorage.setItem("selectedSymptoms", JSON.stringify(selectedSymptoms));

    toast({
      title: "Analysis Complete!",
      description: `Found ${results.length} potential deficiencies.`,
    });

    navigate("/results");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-accent/20 py-12 px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-8 animate-fade-in">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-4 text-sm font-medium">
            <Brain className="w-4 h-4" />
            Step 2 of 2
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-3 text-foreground">Select Your Symptoms</h1>
          <p className="text-muted-foreground">Choose all symptoms you're experiencing for accurate analysis</p>
        </div>

        <Card className="p-6 md:p-8 shadow-lg animate-fade-in mb-6" style={{ animationDelay: "100ms" }}>
          <div className="space-y-4">
            {symptoms.map((symptom, index) => (
              <div
                key={symptom.id}
                className="flex items-start space-x-3 p-4 rounded-lg border-2 border-border hover:border-primary transition-all duration-200 cursor-pointer hover:shadow-sm animate-fade-in"
                onClick={() => handleSymptomToggle(symptom.id)}
                style={{ animationDelay: `${(index + 1) * 50}ms` }}
              >
                <Checkbox
                  id={symptom.id}
                  checked={selectedSymptoms.includes(symptom.id)}
                  onCheckedChange={() => handleSymptomToggle(symptom.id)}
                  className="mt-1"
                />
                <div className="flex-1">
                  <Label
                    htmlFor={symptom.id}
                    className="text-base font-medium cursor-pointer text-foreground"
                  >
                    {symptom.label}
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Linked to: {symptom.deficiencies.join(", ")}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <div className="flex items-center justify-between gap-4">
          <Button
            variant="outline"
            onClick={() => navigate("/profile-setup")}
            size="lg"
            className="border-2"
          >
            Back
          </Button>
          <Button
            onClick={handleAnalyze}
            disabled={selectedSymptoms.length === 0}
            size="lg"
            className="bg-gradient-primary hover:opacity-90 transition-opacity shadow-md flex-1 md:flex-initial"
          >
            Analyze Symptoms ({selectedSymptoms.length})
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SymptomChecker;
